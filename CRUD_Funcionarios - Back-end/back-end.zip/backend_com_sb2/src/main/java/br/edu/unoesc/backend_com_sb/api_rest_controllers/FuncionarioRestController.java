package br.edu.unoesc.backend_com_sb.api_rest_controllers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.edu.unoesc.backend_com_sb.model.Funcionario;

@RestController
@RequestMapping(value = "/api")
public class FuncionarioRestController {
	Funcionario p1 = new Funcionario(1L,"Fulano", 2, new BigDecimal("8.000"));
	Funcionario p2 = new Funcionario(2L,"Ciclano", 4, new BigDecimal("15.000"));
	List<Funcionario> funcionarios;
	
	public FuncionarioRestController() {
		funcionarios = new ArrayList<Funcionario>();
		
		funcionarios.add(p1);
		funcionarios.add(p2);
	}
	
	// Incluir funcionario
	@PostMapping("/funcionario")
	public Funcionario salvarFuncionario(@RequestBody Funcionario fun) {
		System.out.println("Inserindo um novo funcionario...");
		System.out.println(fun);
		
		funcionarios.add(fun);
		
		System.out.println(this.listarFuncionarios());
		
		return fun;
	}
	
	// Alterar funcionario
	@PutMapping("/funcionario")
	public Funcionario atualizarFuncionario(@RequestBody Funcionario fun) {
		Funcionario f = findById(fun.getId());
		System.out.println(f);
		
		f.setNome(fun.getNome());
		f.setNumDep(fun.getNumDep());
		f.setSalario(fun.getSalario());
		
		System.out.println("Atualizando o funcionario...");
		System.out.println(f);
		
		System.out.println(this.listarFuncionarios());
		
		return f;
	}
	
	// Excluir produto
	@DeleteMapping(value = "/funcionario/{id}")
	public void deletarFuncionario(@PathVariable Long id) {
		Funcionario f = findById(id);
		System.out.println(f);
		
		funcionarios.remove(f);
		
		System.out.println("Excluindo funcionario [" + id + "]...");
		
		System.out.println(this.listarFuncionarios());
	}
	
	@GetMapping(value = "/funcionario")
	public List<Funcionario> listarFuncionarios() {
		return funcionarios;
	}
	
	@GetMapping(value = "/funcionario/{id}")
	public Funcionario findById(@PathVariable Long id) {
		for (Funcionario fun : funcionarios) {
			if (fun.getId().equals(id)) {
				return fun;
			}
		}
		
		return null;
	}
}
