package br.edu.unoesc.backend_com_sb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendComSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
